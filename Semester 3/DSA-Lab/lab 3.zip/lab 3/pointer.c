#include<stdio.h>


int main(){
    int var1;
    char var2[10];
    printf("Address of var1 variable %x\n",&var1);
    printf("Address of var1 variable %x\n",var2);
    return 0;
}

int ad(){
    int var[] = {10, 100, 200};
    int i, *ptr[MAX];

}





int twoPointer(){
    //while pointer < another pointer
}
