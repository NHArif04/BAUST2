# DSA-I Lab Report:


## Objective:
    1. to+verb
    2. verb+ing
    3. to know the basic operation of pointer

## Introduction:
....
#### Arithmatic Operation of Pointer:
...

## Discussion:
....
## Conclusion:
....



## <mark>Name of the Experiment:</mark>  
Study of Pointer and its Operations