#include<stdio.h>

int* getPointer(int a){
}

int main(){

}