#include<stdio.h>
int main(){
    int num;
    printf("Enter a number to find cube of it: ");
    scanf("%d",&num);
    printf("\nCube of the given number %d is : %d",num,num*num*num);
return 0;
}